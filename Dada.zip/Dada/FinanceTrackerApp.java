package Dada;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FinanceTrackerApp {

    private static List<Transaction> transactions = new ArrayList<>();
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        while (true) {
            System.out.println("\n--- Personal Finance Tracker ---");
            System.out.println("1. Add Transaction");
            System.out.println("2. View All Transactions");
            System.out.println("3. Update Transaction");
            System.out.println("4. Delete Transaction");
            System.out.println("5. Calculate Balance");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");

            int choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1 -> addTransaction();
                case 2 -> viewTransactions();
                case 3 -> updateTransaction();
                case 4 -> deleteTransaction();
                case 5 -> calculateBalance();
                case 6 -> {
                    System.out.println("Exiting application...");
                    System.exit(0);
                }
                default -> System.out.println("Invalid option. Try again.");
            }
        }
    }

    // CREATE
    private static void addTransaction() {
        String id = String.valueOf(transactions.size());

        String type;
        while (true) {
            System.out.print("Enter type (INCOME/EXPENSE): ");
            type = sc.nextLine();
            if (type.equalsIgnoreCase("INCOME") || type.equalsIgnoreCase("EXPENSE")) break;
            System.out.println("Invalid type.");
        }

        double amount;
        while (true) {
            System.out.print("Enter amount: ");
            amount = sc.nextDouble();
            if (amount > 0) break;
            System.out.println("Amount must be positive.");
        }
        sc.nextLine();

        System.out.print("Enter description: ");
        String description = sc.nextLine();

        System.out.print("Use today's date? (y/n): ");
        String choice = sc.nextLine();
        String date = choice.equalsIgnoreCase("y")
                ? Transaction.getTodayDate()
                : getCustomDate();

        transactions.add(new Transaction(id, type, amount, description, date));
        System.out.println("Transaction added successfully.");
    }

    // READ
    private static void viewTransactions() {
        if (transactions.isEmpty()) {
            System.out.println("No transactions found.");
            return;
        }

        System.out.println("\nID | Type | Amount | Description | Date");
        for (Transaction t : transactions) {
            System.out.println(
                    t.getId() + " | " +
                            t.getType() + " | " +
                            t.getAmount() + " | " +
                            t.getDescription() + " | " +
                            t.getDate()
            );
        }
    }

    // UPDATE
    private static void updateTransaction() {
        System.out.print("Enter Transaction ID to update: ");
        String id = sc.nextLine();

        for (Transaction t : transactions) {
            if (t.getId().equals(id)) {

                System.out.print("New Type (INCOME/EXPENSE): ");
                t.setType(sc.nextLine());

                System.out.print("New Amount: ");
                t.setAmount(sc.nextDouble());
                sc.nextLine();

                System.out.print("New Description: ");
                t.setDescription(sc.nextLine());

                System.out.print("Use today's date? (y/n): ");
                String choice = sc.nextLine();
                t.setDate(choice.equalsIgnoreCase("y")
                        ? Transaction.getTodayDate()
                        : getCustomDate());

                System.out.println("Transaction updated.");
                return;
            }
        }
        System.out.println("Transaction not found.");
    }

    // DELETE
    private static void deleteTransaction() {
        System.out.print("Enter Transaction ID to delete: ");
        String id = sc.nextLine();

        for (Transaction t : transactions) {
            if (t.getId().equals(id)) {
                transactions.remove(t);
                System.out.println("Transaction deleted.");
                return;
            }
        }
        System.out.println("Transaction not found.");
    }

    // BALANCE
    private static void calculateBalance() {
        double income = 0, expense = 0;

        for (Transaction t : transactions) {
            if (t.getType().equals("INCOME")) income += t.getAmount();
            else expense += t.getAmount();
        }

        System.out.println("Total Income: " + income);
        System.out.println("Total Expense: " + expense);
        System.out.println("Current Balance: " + (income - expense));
    }

    // Date input helper
    private static String getCustomDate() {
        System.out.print("Enter date (YYYY-MM-DD): ");
        return sc.nextLine();
    }
}

