package Dada;

import java.time.LocalDate;

public class Transaction {

    private String id;          // immutable
    private String type;        // INCOME or EXPENSE
    private double amount;      // must be positive
    private String description;
    private String date;        // YYYY-MM-DD

    // No-Args Constructor
    public Transaction() {
    }

    // All-Args Constructor
    public Transaction(String id, String type, double amount, String description, String date) {
        this.id = id;
        setType(type);
        setAmount(amount);
        this.description = description;
        this.date = date;
    }

    // Getters
    public String getId() {
        return id;
    }

    public String getType() {
        return type;
    }

    public double getAmount() {
        return amount;
    }

    public String getDescription() {
        return description;
    }

    public String getDate() {
        return date;
    }

    // Setters (NO setter for id)
    public void setType(String type) {
        if (type.equalsIgnoreCase("INCOME") || type.equalsIgnoreCase("EXPENSE")) {
            this.type = type.toUpperCase();
        } else {
            throw new IllegalArgumentException("Type must be INCOME or EXPENSE");
        }
    }

    public void setAmount(double amount) {
        if (amount > 0) {
            this.amount = amount;
        } else {
            throw new IllegalArgumentException("Amount must be positive");
        }
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDate(String date) {
        this.date = date;
    }

    // Date strategy method
    public static String getTodayDate() {
        return LocalDate.now().toString();
    }
}
