package Shawon;

public interface PetBehavior {
    public void feed();
    public void play();
}

