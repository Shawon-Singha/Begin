package Shawon;

public class PetAdoptionSystem {
    public static void main(String[] args) {

        Dog dog = new Dog("Buddy", 3, "Golden Retriever");
        Cat cat = new Cat("Whiskers", 2, "Persian");

        Owner owner = new Owner("Shawon", "Dhaka, Bangladesh");

        owner.adoptPet(dog);
        owner.adoptPet(cat);

        System.out.println("\n--- Pet Interactions ---");
        dog.makeSound();
        dog.feed();
        dog.play();

        System.out.println();

        cat.makeSound();
        cat.feed();
        cat.play();

        System.out.println("\n--- Details ---");
        System.out.println(dog);
        System.out.println(cat);

        System.out.println("\nOwner Name: " + owner.getName());
        System.out.println("Address: " + owner.getAddress());
        System.out.println("Total Pets Adopted: " + owner.getPetsAdopted());
    }
}

